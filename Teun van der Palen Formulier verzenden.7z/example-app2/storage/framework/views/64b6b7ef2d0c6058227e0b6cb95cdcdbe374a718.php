	

<?php $__env->startSection('top-content'); ?>
<h1>Hello world</h1>
<p>
	Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae illum itaque doloremque nam dolores maiores delectus quam corrupti, ipsa necessitatibus sunt saepe atque. Laudantium veniam repudiandae illo molestiae dolor inventore explicabo, temporibus ullam architecto quaerat illum sit. Molestias qui aut aliquid tenetur recusandae saepe odit numquam repellendus, dolor, laudantium sequi.
</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-A'); ?>
<h1>Bottom content A</h1>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At explicabo porro consequuntur, doloribus saepe numquam voluptates minima ipsum iste nulla?</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-B'); ?>
<h1>Bottom content B</h1>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At explicabo porro consequuntur, doloribus saepe numquam voluptates minima ipsum iste nulla?</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views/home.blade.php ENDPATH**/ ?>
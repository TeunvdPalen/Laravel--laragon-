

<?php $__env->startSection('aside'); ?>
	<h2>Quick links</h2>
	<?php echo $__env->make('admin/includes/admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias reiciendis asperiores ducimus, sapiente in ab consectetur nihil odit magnam corporis veniam facere corrupti, sint a modi quis iusto, eligendi tenetur.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	<h1>Privacy beleid</h1>
	<h2>Kop 1</h2>
	<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequatur, fugiat.</p>
	<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Debitis aliquid cum voluptate adipisci libero natus eius velit fuga temporibus hic iste aperiam, exercitationem accusamus corporis culpa nam incidunt quaerat vitae. Animi, neque veritatis itaque architecto laboriosam, perspiciatis consequatur odio eius molestiae eos est dolores deserunt amet eligendi veniam ex ullam rem dicta nostrum non. Nesciunt veritatis minima a ad? Voluptas?</p>
	<h2>Kop 2</h2>
	<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Neque distinctio at voluptatum nisi. Commodi tenetur ducimus doloremque? Perferendis nam veniam incidunt ipsum non eius laudantium modi quibusdam mollitia officiis at, saepe pariatur, id iusto reiciendis autem consectetur ducimus? Eum, architecto.</p>
	<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Non, vitae dignissimos perspiciatis fugit nostrum cum quasi quidem id. Ab, laudantium!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views/admin/privacy.blade.php ENDPATH**/ ?>


<?php $__env->startSection('top-content'); ?>
	<h1>Contact</h1>

	<?php echo $__env->make('contact/includes/form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-A'); ?>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique, quo maiores assumenda adipisci pariatur reprehenderit et quasi a recusandae fugit vero quia delectus veritatis incidunt magnam, blanditiis quidem exercitationem porro laboriosam. Est, at sit dolorem eveniet aperiam eaque deleniti voluptates possimus dicta quo natus, recusandae facilis praesentium iusto quia reiciendis autem, animi cumque dolorum eum ipsam incidunt veritatis dolore eius.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-B'); ?>
<h1>Bottom content</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis excepturi eum sit suscipit, odio esse soluta alias voluptatibus omnis quod, eveniet unde delectus magni quidem ipsum? Aspernatur corporis rem suscipit.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views/contact/contact.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('layouts/includes/meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<title>Welkom website</title>
	<link rel="stylesheet" href="/css/style.css">
</head>
<body>

	<div class="container">
	<?php echo $__env->make('layouts/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<main class="main-content">
		<div class="container">
			<div class="top-content">
				<?php echo $__env->yieldContent('top-content'); ?>
			</div>
			<div class="bottom-content">
				<div>
					<?php echo $__env->yieldContent('bottom-content-A'); ?>
				</div>
				<div>
					<?php echo $__env->yieldContent('bottom-content-B'); ?>
				</div>
			</div>
		</div>
	</main>

	<?php echo $__env->make('layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/default.blade.php ENDPATH**/ ?>
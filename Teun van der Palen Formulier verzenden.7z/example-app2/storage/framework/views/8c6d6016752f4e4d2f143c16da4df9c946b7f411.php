<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('layouts/includes/meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<title>Welkom website</title>
	<link rel="stylesheet" href="/css/style.css">
</head>
<body>

	<div class="container">
		<div class="layout">
			<div class="aside">
			<?php echo $__env->yieldContent('aside'); ?>
			</div>
			<div class="main">
			<?php echo $__env->yieldContent('main'); ?>
			</div>
		</div>
	</div>


</body>
</html><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
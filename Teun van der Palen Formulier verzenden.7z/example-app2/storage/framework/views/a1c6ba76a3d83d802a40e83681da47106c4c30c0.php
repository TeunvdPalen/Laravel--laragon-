<nav class="admin-nav">
	<a href="/">Home</a>
	<a href="/admin">Admin paneel</a>
	<a href="/admin/contact-berichten">Contact berichten</a>
	<a href="/admin/nieuws-berichten">Nieuws berichten</a>
	<a href="/admin/privacy">Privacy</a>
</nav><?php /**PATH C:\laragon\www\example-app2\resources\views/admin/includes/admin-nav.blade.php ENDPATH**/ ?>
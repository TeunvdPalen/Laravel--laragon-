<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
</head>
<body>
	<h1>Hallo <?php echo e($data['naam']); ?></h1>
	<p>Dankjewel voor een score van <?php echo e($data['score']); ?></p>
	<hr>
	<?php echo e($data['bericht']); ?>

</body>
</html><?php /**PATH C:\laragon\www\example-app2\resources\views/emails/review-message.blade.php ENDPATH**/ ?>
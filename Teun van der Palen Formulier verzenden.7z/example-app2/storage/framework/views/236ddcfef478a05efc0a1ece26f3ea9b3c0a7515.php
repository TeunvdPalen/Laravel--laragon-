

<?php $__env->startSection('top-content'); ?>
<h1>About this</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci facilis aspernatur aliquam quis reiciendis fugiat obcaecati soluta natus. Ratione dolorum praesentium voluptate quod ducimus beatae ea reprehenderit accusantium aliquam blanditiis aliquid sequi sint maiores, animi incidunt molestiae excepturi architecto fuga atque consequuntur ex tempore consectetur sit impedit. Debitis, aut consectetur, corporis doloremque itaque, beatae obcaecati ducimus modi quam autem iste a adipisci impedit quae magnam laboriosam ratione quis dolorem. Explicabo eligendi reiciendis fugiat voluptas est non, pariatur nam ipsam. Maxime nam ipsum sed laudantium consequatur perferendis, labore unde ullam perspiciatis omnis quidem nulla possimus officia architecto quibusdam rem ipsam dolorum, ducimus corrupti veritatis natus magnam debitis. In quisquam dolores nobis error ut modi quis architecto. Libero accusamus quisquam quae nam, dolorum quia nostrum culpa provident velit, repellendus dolore corrupti dignissimos animi. Inventore tempore non sed culpa! Est minima sit quas libero inventore architecto reprehenderit fugit! Assumenda harum quia provident voluptatem cupiditate enim ex ipsam laboriosam, odit ratione qui quae illo. Incidunt atque nobis iure, suscipit quos esse laborum distinctio cupiditate dignissimos eveniet dolor, sed, et voluptatum accusantium quasi. Architecto culpa iure cum provident suscipit, aut assumenda! Ad ducimus consequatur sequi enim. Iusto maxime, voluptatibus laboriosam perferendis ratione aspernatur necessitatibus nobis.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-A'); ?>
<img src="https://picsum.photos/500/300" alt="">
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci, velit.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content-B'); ?>
<img src="https://picsum.photos/500/300" alt="">
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci, velit.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views/about/about.blade.php ENDPATH**/ ?>
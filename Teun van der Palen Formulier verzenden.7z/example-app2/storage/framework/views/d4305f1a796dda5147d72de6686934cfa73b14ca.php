<form method="POST" action="/review"  novalidate>
	<?php echo csrf_field(); ?>

	<?php if(session('status')): ?>
		<p><?php echo e(session('status')); ?></p>
	<?php endif; ?>
	<div class="review">
		Naam: <input type="text" name="naam" value="<?php echo e(old('naam')); ?>">
		<?php $__errorArgs = ['naam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="error"><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="review">
		Email: <input type="email" name="email" value="<?php echo e(old('email')); ?>">
		<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="error"><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="review">
		Bericht: <br>
		<textarea name="bericht"><?php echo e(old('bericht')); ?></textarea>
		<?php $__errorArgs = ['bericht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="error"><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="review">
		Score:
		<?php for($i = 0; $i < 11; $i++): ?>
		<input type="radio" name="score" id="<?php echo e($i); ?>" value="<?php echo e($i); ?>" <?php echo e(old('score') == $i ? "checked" : ""); ?>>
		<label for="<?php echo e($i); ?>"><?php echo e($i); ?></label>
		<?php endfor; ?>
		<?php $__errorArgs = ['score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="error"><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	
	<div class="review">
		Ik accepteer het privacybeleid: <input type="checkbox" name="privacy" <?php echo e(old('privacy') == true ? "checked" : ""); ?>>
		<?php $__errorArgs = ['privacy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="error"><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	
	<div class="review">
		<input type="submit" value="Verzenden">
	</div>
</form><?php /**PATH C:\laragon\www\example-app2\resources\views/contact/includes/review_form.blade.php ENDPATH**/ ?>


<?php $__env->startSection('aside'); ?>
	<h2>Quick links</h2>
	<?php echo $__env->make('admin/includes/admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias reiciendis asperiores ducimus, sapiente in ab consectetur nihil odit magnam corporis veniam facere corrupti, sint a modi quis iusto, eligendi tenetur.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	<h1>Admin</h1>
	<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequatur, fugiat.</p>
	<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Non, vitae dignissimos perspiciatis fugit nostrum cum quasi quidem id. Ab, laudantium!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views/admin/index.blade.php ENDPATH**/ ?>
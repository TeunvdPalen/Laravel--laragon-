

<?php $__env->startSection('top-content'); ?>
	<h1>Review</h1>

	<?php echo $__env->make('contact/includes/review_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\example-app2\resources\views//contact/review.blade.php ENDPATH**/ ?>
<nav>
	<a href="/">Home</a>
	<a href="/contact">Contact</a>
	<a href="/about">About</a>
	<a href="/review">Review</a>
</nav><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/includes/nav.blade.php ENDPATH**/ ?>
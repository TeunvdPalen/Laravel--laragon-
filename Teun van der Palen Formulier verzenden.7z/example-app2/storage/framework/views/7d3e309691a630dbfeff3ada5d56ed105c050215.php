<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
</head>
<body>
		<h1>Bericht van <?php echo e($data['naam']); ?> is verzonden</h1>
		<p>E-mailadres: <?php echo e($data['email']); ?></p>
		<hr>
		<?php echo e($data['bericht']); ?>

</body>
</html><?php /**PATH C:\laragon\www\example-app2\resources\views/emails/contact-message-sent.blade.php ENDPATH**/ ?>
<footer class="main-footer">
	<p>Copyright <?php echo e(date("Y")); ?> <a href="/privacy">Privacybeleid</a> - <a href="/admin">Admin</a></p>
</footer><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>
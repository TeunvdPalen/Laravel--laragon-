<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>
</head>
<body>
	<h1>Review van <?php echo e($data['naam']); ?></h1>
	<h2><?php echo e($data['email']); ?></h2>
	<p>heeft een score gegeven van: <?php echo e($data['score']); ?></p>
	<h2>review bericht</h2>
	<p><?php echo e($data['bericht']); ?></p>
</body>
</html><?php /**PATH C:\laragon\www\example-app2\resources\views/emails/review-review.blade.php ENDPATH**/ ?>
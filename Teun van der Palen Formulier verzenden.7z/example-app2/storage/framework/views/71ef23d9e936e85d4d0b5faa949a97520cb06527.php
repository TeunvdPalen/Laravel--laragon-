<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge"><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/includes/meta.blade.php ENDPATH**/ ?>
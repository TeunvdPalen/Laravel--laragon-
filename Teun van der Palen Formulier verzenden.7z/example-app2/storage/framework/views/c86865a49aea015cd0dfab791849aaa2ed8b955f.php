<div class="header">
	<h1>Logo</h1>
	<?php echo $__env->make('layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\example-app2\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>
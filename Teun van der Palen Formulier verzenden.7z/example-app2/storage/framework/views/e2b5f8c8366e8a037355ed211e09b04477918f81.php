<form method="POST" action="/contact"  novalidate>
	<?php echo csrf_field(); ?>

	<?php if(session('status')): ?>
		<p><?php echo e(session('status')); ?></p>
	<?php endif; ?>
	<div>
		Naam: <input type="text" name="naam" value="<?php echo e(old('naam')); ?>">
		<?php $__errorArgs = ['naam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div>
		Email: <input type="email" name="email" value="<?php echo e(old('email')); ?>">
		<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div>
		Bericht: <br>
		<textarea name="bericht"><?php echo e(old('bericht')); ?></textarea>
		<?php $__errorArgs = ['bericht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span><?php echo e($message); ?></span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div>
		<input type="submit" value="Verzenden">
	</div>
</form><?php /**PATH C:\laragon\www\example-app2\resources\views/contact/includes/form.blade.php ENDPATH**/ ?>
@extends('layouts/admin')

@section('aside')
	<h2>Quick links</h2>
	@include('admin/includes/admin-nav')
	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias reiciendis asperiores ducimus, sapiente in ab consectetur nihil odit magnam corporis veniam facere corrupti, sint a modi quis iusto, eligendi tenetur.</p>
@endsection

@section('main')
	<h1>nieuws-berichten</h1>
	<h2>Bericht 1</h2>
	<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Earum quisquam expedita molestiae dolore? Odio quidem quod saepe dolor voluptatibus? Sunt quaerat, ab, dolorum magnam est voluptas commodi eos illo velit reiciendis ad non animi aspernatur veritatis reprehenderit at. Atque, temporibus.</p>
	<h2>Bericht 2</h2>
	<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis ab nostrum mollitia totam nesciunt aut et incidunt quisquam quos magni ipsam delectus, libero aliquid aperiam facere commodi! Consequuntur doloribus, labore impedit voluptates accusantium dignissimos suscipit ab praesentium omnis id recusandae maxime vero unde ea ipsam minus sed quasi repellendus quas accusamus eligendi repudiandae. Sed fugit quae iure, accusantium a asperiores deleniti? Doloremque culpa pariatur ad voluptas soluta fugit, assumenda inventore.</p>
@endsection
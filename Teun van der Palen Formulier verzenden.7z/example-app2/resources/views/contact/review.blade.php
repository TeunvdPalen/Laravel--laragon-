@extends('layouts/default')

@section('top-content')
	<h1>Review</h1>

	@include('contact/includes/review_form')
@endsection

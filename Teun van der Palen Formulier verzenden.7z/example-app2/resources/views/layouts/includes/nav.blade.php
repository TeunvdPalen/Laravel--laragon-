<nav>
	<a href="/">Home</a>
	<a href="/contact">Contact</a>
	<a href="/about">About</a>
	<a href="/review">Review</a>
</nav>
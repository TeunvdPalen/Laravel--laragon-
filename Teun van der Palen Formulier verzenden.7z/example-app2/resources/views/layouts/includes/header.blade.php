<div class="header">
	<h1>Logo</h1>
	@include('layouts/includes/nav')
</div>
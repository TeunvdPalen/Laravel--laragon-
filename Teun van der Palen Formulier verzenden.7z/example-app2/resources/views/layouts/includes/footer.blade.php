<footer class="main-footer">
	<p>Copyright {{ date("Y") }} <a href="/privacy">Privacybeleid</a> - <a href="/admin">Admin</a></p>
</footer>
@extends('layouts.default')	

@section('top-content')
<h1>Hello world</h1>
<p>
	Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae illum itaque doloremque nam dolores maiores delectus quam corrupti, ipsa necessitatibus sunt saepe atque. Laudantium veniam repudiandae illo molestiae dolor inventore explicabo, temporibus ullam architecto quaerat illum sit. Molestias qui aut aliquid tenetur recusandae saepe odit numquam repellendus, dolor, laudantium sequi.
</p>
@endsection

@section('bottom-content-A')
<h1>Bottom content A</h1>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At explicabo porro consequuntur, doloribus saepe numquam voluptates minima ipsum iste nulla?</p>
@endsection

@section('bottom-content-B')
<h1>Bottom content B</h1>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. At explicabo porro consequuntur, doloribus saepe numquam voluptates minima ipsum iste nulla?</p>
@endsection
@extends('layouts.default')	

@section('main-content')
            <!-- Content -->
            <section id="content" class="main">
                <h2>About us</h2>
                @include('pages/includes/lorem')
            </section>
@endsection
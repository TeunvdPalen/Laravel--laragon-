@extends('layouts.default')	

@section('main-content')

    <!-- Content -->
    <section id="content" class="main">
        <h2>Get started</h2>
        @include('pages/includes/lorem')
    </section>
@endsection()

<!DOCTYPE HTML>
<!--
	Stellar by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
    <title>Stellar by HTML5 UP</title>
		<?php echo $__env->make('layouts/includes/meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="is-preload">

    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Header -->
        <?php echo $__env->make('layouts/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Nav -->
        <?php echo $__env->make('layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Main -->
        <div id="main">

        <?php echo $__env->yieldContent('main-content'); ?>

        </div>

        <!-- Footer -->
        <footer id="footer">
        <?php echo $__env->make('layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>

    </div>

    <!-- Scripts -->
    <?php echo $__env->make('layouts/includes/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\laragon\www\Opdracht---Controllers-Routes-en-Views\resources\views/layouts/default.blade.php ENDPATH**/ ?>
<nav id="nav">
	<ul>
			<li><a href="/" class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>">Home</a></li>
			<li><a href="/about" class="<?php echo e((request()->is('about')) ? 'active' : ''); ?>">About</a></li>
			<li><a href="/getstarted" class="<?php echo e((request()->is('getstarted')) ? 'active' : ''); ?>">Get Started</a></li>
			<li><a href="/contact" class="<?php echo e((request()->is('contact')) ? 'active' : ''); ?>">Contact</a></li>
	</ul>
</nav><?php /**PATH C:\laragon\www\Opdracht---Controllers-Routes-en-Views\resources\views/layouts/includes/nav.blade.php ENDPATH**/ ?>
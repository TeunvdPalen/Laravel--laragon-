	

<?php $__env->startSection('main-content'); ?>
            <!-- Content -->
            <section id="content" class="main">
                <h2>About us</h2>
                <?php echo $__env->make('pages/includes/lorem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Opdracht---Controllers-Routes-en-Views\resources\views//pages/about.blade.php ENDPATH**/ ?>
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/jquery.scrollex.min.js"></script>
<script src="/assets/js/jquery.scrolly.min.js"></script>
<script src="/assets/js/browser.min.js"></script>
<script src="/assets/js/breakpoints.min.js"></script>
<script src="/assets/js/util.js"></script>
<script src="/assets/js/main.js"></script><?php /**PATH C:\laragon\www\Opdracht---Controllers-Routes-en-Views\resources\views/layouts/includes/scripts.blade.php ENDPATH**/ ?>